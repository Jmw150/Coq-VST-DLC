int f (int b) {
  int i, a;
  for (i=b+1; i*i>b; i--) {
    a=i;
  }
  return a;
}
