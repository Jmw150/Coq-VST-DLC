int iden (int x) {
  int y = x;
  int * p = & y;
  return * p;
}

int main () {
}
