#include <stdio.h>

int main(void) {
  printf("Hello, world!\n");
  fprintf(stdout, "This is %s %d.\n", "line", 2);
  return 0;
}
