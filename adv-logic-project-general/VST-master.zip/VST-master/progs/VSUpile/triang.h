int Triang_nth(int n);

  
