struct list {
  int n;
  struct list *next;
};

struct pile {
  struct list *head;
};

