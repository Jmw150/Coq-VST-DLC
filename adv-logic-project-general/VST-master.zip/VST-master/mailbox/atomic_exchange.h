#include "threads.h"

int simulate_atomic_exchange(int *tgt, lock_t *l, int v);
